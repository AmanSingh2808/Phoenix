package com.example.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.example.demo.model.Franchise;

public interface FranchiseRepository extends JpaRepository<Franchise, Long> {}
