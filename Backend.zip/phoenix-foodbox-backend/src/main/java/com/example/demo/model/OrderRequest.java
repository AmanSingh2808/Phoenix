package com.example.demo.model;

import java.util.List;

public record OrderRequest(
        Long customerId,
        Long outletId,
        double totalAmount,
        List<OrderItemRequest> items
) {}
