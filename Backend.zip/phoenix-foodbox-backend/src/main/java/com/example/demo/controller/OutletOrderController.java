package com.example.demo.controller;

import java.util.List;
import org.springframework.web.bind.annotation.*;

import com.example.demo.model.*;
import com.example.demo.repository.OrderRepository;

@RestController
@RequestMapping("/api/outlet-orders")
@CrossOrigin(origins = "http://localhost:4200")
public class OutletOrderController {

    private final OrderRepository orderRepo;

    public OutletOrderController(OrderRepository orderRepo) {
        this.orderRepo = orderRepo;
    }
  
    // View new orders
    @GetMapping("/{outletId}")
    public List<Order> getOrders(@PathVariable Long outletId) {
        return orderRepo.findByOutletIdAndStatusIn(
            outletId,
            List.of(
                OrderStatus.PLACED,
                OrderStatus.ACCEPTED,
                OrderStatus.IN_PROGRESS,
                OrderStatus.READY
            )
        );
    }


    // Accept
    @PutMapping("/{orderId}/accept")
    public Order accept(@PathVariable Long orderId) {
        Order o = orderRepo.findById(orderId).orElseThrow();
        o.setStatus(OrderStatus.ACCEPTED);
        return orderRepo.save(o);
    }

    // Start cooking
    @PutMapping("/{orderId}/start")
    public Order start(@PathVariable Long orderId) {
        Order o = orderRepo.findById(orderId).orElseThrow();
        o.setStatus(OrderStatus.IN_PROGRESS);
        return orderRepo.save(o);
    }

    // Ready
    @PutMapping("/{orderId}/ready")
    public Order ready(@PathVariable Long orderId) {
        Order o = orderRepo.findById(orderId).orElseThrow();
        o.setStatus(OrderStatus.READY);
        return orderRepo.save(o);
    }

    // Complete
    @PutMapping("/{orderId}/complete")
    public Order complete(@PathVariable Long orderId) {
        Order o = orderRepo.findById(orderId).orElseThrow();
        o.setStatus(OrderStatus.COMPLETED);
        return orderRepo.save(o);
    }
}
