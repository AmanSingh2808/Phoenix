package com.example.demo.model;

public enum OrderStatus {
    PLACED,
    ACCEPTED,
    IN_PROGRESS,
    READY,
    COMPLETED
}
