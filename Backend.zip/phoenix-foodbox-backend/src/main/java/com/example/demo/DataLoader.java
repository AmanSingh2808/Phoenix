package com.example.demo;

import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;

import com.example.demo.model.*;
import com.example.demo.repository.*;

@Component
public class DataLoader {

    @Bean
    CommandLineRunner loadInitialData(
            UserRepository userRepo,
            FranchiseRepository franchiseRepo,
            OutletRepository outletRepo,
            MenuItemRepository menuRepo) {

        return args -> {

            /* ---------- USERS ---------- */
            if (userRepo.count() == 0) {
                userRepo.save(new User("admin", "admin123", Role.ADMIN));
                userRepo.save(new User("owner1", "pass123", Role.FRANCHISE_OWNER));
                userRepo.save(new User("manager1", "pass123", Role.OUTLET_MANAGER));
                userRepo.save(new User("customer1", "pass123", Role.CUSTOMER));
            }

            /* ---------- FRANCHISES ---------- */
            Franchise burgerHub;
            Franchise pizzaPalace;

            if (franchiseRepo.count() == 0) {
                burgerHub = franchiseRepo.save(
                        new Franchise("Burger Hub", "Fast food burgers")
                );
                pizzaPalace = franchiseRepo.save(
                        new Franchise("Pizza Palace", "Italian style pizzas")
                );
            } else {
                burgerHub = franchiseRepo.findAll().get(0);
                pizzaPalace = franchiseRepo.findAll().get(1);
            }

            /* ---------- OUTLETS ---------- */
            Outlet bhDowntown;
            Outlet bhMall;
            Outlet ppNorth;

            if (outletRepo.count() == 0) {
                bhDowntown = outletRepo.save(
                        new Outlet("Burger Hub - Downtown", "City Center", burgerHub)
                );
                bhMall = outletRepo.save(
                        new Outlet("Burger Hub - Mall", "Mega Mall", burgerHub)
                );
                ppNorth = outletRepo.save(
                        new Outlet("Pizza Palace - North", "North Zone", pizzaPalace)
                );
            } else {
                bhDowntown = outletRepo.findAll().get(0);
                bhMall = outletRepo.findAll().get(1);
                ppNorth = outletRepo.findAll().get(2);
            }

            /* ---------- MENU ITEMS ---------- */
            if (menuRepo.count() == 0) {

                menuRepo.save(new MenuItem("Cheese Burger", 120, bhDowntown));
                menuRepo.save(new MenuItem("Veg Burger", 100, bhDowntown));

                menuRepo.save(new MenuItem("Chicken Burger", 150, bhMall));
                menuRepo.save(new MenuItem("French Fries", 80, bhMall));

                menuRepo.save(new MenuItem("Margherita Pizza", 250, ppNorth));
                menuRepo.save(new MenuItem("Pepperoni Pizza", 300, ppNorth));
            }
        };
    }
}
