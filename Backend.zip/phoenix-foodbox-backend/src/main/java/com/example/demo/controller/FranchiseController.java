package com.example.demo.controller;

import java.util.List;
import org.springframework.web.bind.annotation.*;

import com.example.demo.model.*;
import com.example.demo.repository.*;

@RestController
@RequestMapping("/api/franchises")
@CrossOrigin
public class FranchiseController {

    private final FranchiseRepository franchiseRepo;
    private final OutletRepository outletRepo;

    public FranchiseController(FranchiseRepository franchiseRepo,
                               OutletRepository outletRepo) {
        this.franchiseRepo = franchiseRepo;
        this.outletRepo = outletRepo;
    }

    // GET all franchises
    @GetMapping
    public List<Franchise> getAllFranchises() {
        return franchiseRepo.findAll();
    }

    // GET outlets for a franchise
    @GetMapping("/{id}/outlets")
    public List<Outlet> getOutlets(@PathVariable Long id) {
        return outletRepo.findByFranchiseId(id);
    }
}
