package com.example.demo.model;

import jakarta.persistence.*;
import java.util.List;

@Entity
@Table(name = "orders")
public class Order {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private double totalAmount;

    @Enumerated(EnumType.STRING)
    private OrderStatus status;

    @ManyToOne
    private User customer;

    @ManyToOne
    private Outlet outlet;

    @OneToMany(mappedBy = "order", cascade = CascadeType.ALL)
    private List<OrderItem> items;


    public Order() {}

    public Order(User customer, Outlet outlet, double totalAmount) {
        this.customer = customer;
        this.outlet = outlet;
        this.totalAmount = totalAmount;
        this.status = OrderStatus.PLACED;
    }

    public Long getId() { return id; }
    public double getTotalAmount() { return totalAmount; }
    public OrderStatus getStatus() { return status; }

    public User getCustomer() { return customer; }
    public Outlet getOutlet() { return outlet; }

    public List<OrderItem> getItems() { return items; }
    public void setItems(List<OrderItem> items) { this.items = items; }

    public void setStatus(OrderStatus status) {
        this.status = status;
    }
}
