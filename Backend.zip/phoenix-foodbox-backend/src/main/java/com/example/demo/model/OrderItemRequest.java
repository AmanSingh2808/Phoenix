package com.example.demo.model;

public record OrderItemRequest(
        String name,
        double price,
        int quantity
) {}
