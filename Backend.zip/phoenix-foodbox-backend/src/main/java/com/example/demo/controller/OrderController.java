package com.example.demo.controller;

import java.util.ArrayList;
import java.util.List;
import org.springframework.web.bind.annotation.*;

import com.example.demo.model.*;
import com.example.demo.repository.*;

@RestController
@RequestMapping("/api/orders")
@CrossOrigin(origins = "http://localhost:4200")
public class OrderController {

    private final OrderRepository orderRepo;
    private final UserRepository userRepo;
    private final OutletRepository outletRepo;

    public OrderController(OrderRepository orderRepo,
                           UserRepository userRepo,
                           OutletRepository outletRepo) {
        this.orderRepo = orderRepo;
        this.userRepo = userRepo;
        this.outletRepo = outletRepo;
    }

    @PostMapping("/place")
    public Order placeOrder(@RequestBody OrderRequest request) {

        User customer = userRepo.findById(request.customerId()).orElseThrow();
        Outlet outlet = outletRepo.findById(request.outletId()).orElseThrow();

        // Step 1: Create and save Order
        Order order = new Order(customer, outlet, request.totalAmount());
        order = orderRepo.save(order);

        // Step 2: Create OrderItems (NO stream / lambda)
        List<OrderItem> items = new ArrayList<>();

        for (OrderItemRequest reqItem : request.items()) {
            OrderItem item = new OrderItem();
            item.setItemName(reqItem.name());
            item.setPrice(reqItem.price());
            item.setQuantity(reqItem.quantity());
            item.setOrder(order);
            items.add(item);
        }

        // Step 3: Attach items to Order
        order.setItems(items);

        // Step 4: Save again (cascade saves OrderItems)
        return orderRepo.save(order);
    }




    @GetMapping("/customer/{id}")
    public List<Order> getCustomerOrders(@PathVariable Long id) {
        return orderRepo.findByCustomerId(id);
    }
}
