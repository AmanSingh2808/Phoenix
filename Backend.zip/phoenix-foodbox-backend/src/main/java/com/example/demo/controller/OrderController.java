package com.example.demo.controller;

import java.util.ArrayList;
import java.util.List;
import org.springframework.web.bind.annotation.*;

import com.example.demo.model.*;
import com.example.demo.repository.*;

@RestController
@RequestMapping("/api/orders")
@CrossOrigin(origins = "http://localhost:4200")
public class OrderController {

    private final OrderRepository orderRepo;
    private final UserRepository userRepo;
    private final OutletRepository outletRepo;

    public OrderController(OrderRepository orderRepo,
                           UserRepository userRepo,
                           OutletRepository outletRepo) {
        this.orderRepo = orderRepo;
        this.userRepo = userRepo;
        this.outletRepo = outletRepo;
    }

    @PostMapping("/place")
    public Order place(@RequestBody OrderRequest req) {

        User customer = userRepo.findById(req.customerId()).orElseThrow();
        Outlet outlet = outletRepo.findById(req.outletId()).orElseThrow();

        Order order = new Order(customer, outlet, req.totalAmount());
        Order saved = orderRepo.save(order);

        List<OrderItem> items = req.items().stream()
            .map(i -> new OrderItem(i.name(), i.price(), i.quantity(), saved))
            .toList();

        saved.setItems(items);

        return orderRepo.save(saved);
    }

    @GetMapping("/outlet/{outletId}")
    public List<Order> getOutletOrders(@PathVariable Long outletId) {
        return orderRepo.findByOutletId(outletId);
    }
}
