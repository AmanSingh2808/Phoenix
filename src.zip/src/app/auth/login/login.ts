import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { AuthService } from '../../services/auth.service';
import { User } from '../../models/user';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [FormsModule, CommonModule],
  templateUrl: './login.html',
  styleUrl: './login.css'
})
export class LoginComponent {

  username = '';
  password = '';
  error = '';

  constructor(
    private auth: AuthService,
    private router: Router
  ) {}

  onLogin() {

    const user: User = {
      username: this.username,
      password: this.password,
      role: null as any
    };

    this.auth.login(user).subscribe({

      next: (res) => {

        if (!res) {
          this.error = 'Invalid credentials';
          return;
        }

        this.auth.saveUser(res);

        switch (res.role) {

          case 'ADMIN':
            this.router.navigate(['/admin']);
            break;

          case 'FRANCHISE_OWNER':
            this.router.navigate(['/franchise']);
            break;

          case 'OUTLET_MANAGER':
            this.router.navigate(['/outlet']);
            break;

          case 'CUSTOMER':
            this.router.navigate(['/customer']);
            break;
        }
      },

      error: () => {
        this.error = 'Login failed';
      }
    });
  }
}
