import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-dashboard',
  imports: [],
  templateUrl: './dashboard.html',
  styleUrl: './dashboard.css',
})
export class Dashboard {

    
  constructor(private router: Router) {}

  goToApprovals() {
    this.router.navigate(['/admin/approvals']);
  }

  goToOutlets() {
    this.router.navigate(['/admin/outlets']);
  }

  goToReports() {
    this.router.navigate(['/admin/reports']);
  }

  logout() {
    localStorage.clear();
    this.router.navigate(['/login']);
  }

}

    
  


