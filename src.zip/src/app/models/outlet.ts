export interface Outlet {
    id: number;
    name: string;
    location: string;
  }
  