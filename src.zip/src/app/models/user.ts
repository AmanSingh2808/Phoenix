export enum Role {
    ADMIN = 'ADMIN',
    FRANCHISE_OWNER = 'FRANCHISE_OWNER',
    OUTLET_MANAGER = 'OUTLET_MANAGER',
    CUSTOMER = 'CUSTOMER'
  }
  
  export interface User {
    id?: number;
    username: string;
    password: string;
    role: Role;
  }
  