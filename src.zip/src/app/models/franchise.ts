export interface Franchise {
    id: number;
    name: string;
    description: string;
  }
  