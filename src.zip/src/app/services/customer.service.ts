import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Franchise } from '../models/franchise';
import { Outlet } from '../models/outlet';
import { MenuItem } from '../models/menu-items';
import { Observable } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class CustomerService {

  private baseUrl = 'http://localhost:8085/api';

  constructor(private http: HttpClient) {}

  getFranchises(): Observable<Franchise[]> {
    return this.http.get<Franchise[]>(`${this.baseUrl}/franchises`);
  }

  getOutletsByLocation(location: string) {
    return this.http.get<Outlet[]>(
      `http://localhost:8085/api/outlets?location=${location}`
    );
  }

  placeOrder(order: any) {
    return this.http.post(
      'http://localhost:8085/api/orders/place',
      order
    );
  }
  
  getMyOrders(customerId: number) {
    return this.http.get(
      `http://localhost:8085/api/orders/customer/${customerId}`
    );
  }
  
  

  getOutlets(franchiseId: number): Observable<Outlet[]> {
    return this.http.get<Outlet[]>(
      `${this.baseUrl}/franchises/${franchiseId}/outlets`
    );
  }

  getMenu(outletId: number) {
    return this.http.get<MenuItem[]>(
      `http://localhost:8085/api/outlets/${outletId}/menu`
    );
  }
}
