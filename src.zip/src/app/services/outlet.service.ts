import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({ providedIn: 'root' })
export class OutletService {

  private base = 'http://localhost:8085/api/outlet-orders';

  constructor(private http: HttpClient) {}

  getOrders(outletId: number) {
  return this.http.get<any[]>(`http://localhost:8085/api/orders/outlet/${outletId}`);
}


  accept(orderId: number) {
    return this.http.put(`${this.base}/${orderId}/accept`, {});
  }

  start(orderId: number) {
    return this.http.put(`${this.base}/${orderId}/start`, {});
  }

  ready(orderId: number) {
    return this.http.put(`${this.base}/${orderId}/ready`, {});
  }

  complete(orderId: number) {
    return this.http.put(`${this.base}/${orderId}/complete`, {});
  }

  getMyOutlet(managerId: number) {
  return this.http.get<any>(
    `http://localhost:8085/api/outlets/manager/${managerId}`
  );
}



}
