import { Routes } from '@angular/router';
import { LoginComponent } from './auth/login/login';
import { Dashboard as AdminDashboard } from './admin/dashboard/dashboard';
import { Dashboard as FranchiseDashboard } from './franchise/dashboard/dashboard';
import { Dashboard as OutletDashboard } from './outlet/dashboard/dashboard';
import { CustomerDashboardComponent } from './customer/dashboard/dashboard';
import { OutletManagerComponent } from './outlet/manager/manager';

export const routes: Routes = [
  { path: '', component: LoginComponent },
  { path: 'admin', component: AdminDashboard },
  { path: 'franchise', component: FranchiseDashboard },
  { path: 'outlet', component: OutletManagerComponent },
  { path: 'customer', component: CustomerDashboardComponent },
  { path: '**', redirectTo: '' },

  
];