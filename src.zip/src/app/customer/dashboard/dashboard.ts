import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CustomerService } from '../../../app/services/customer.service';
import { Franchise } from '../../models/franchise';
import { Outlet } from '../../models/outlet';
import { MenuItem } from '../../models/menu-items';

@Component({
  selector: 'app-customer-dashboard',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './dashboard.html',
  styleUrl: './dashboard.css'
})
export class CustomerDashboardComponent implements OnInit {

  franchises: Franchise[] = [];
  outlets: Outlet[] = [];
  locations: string[] = ['City Center', 'Mega Mall', 'North Zone'];
  selectedLocation = '';
  selectedOutletId: number | null = null;


  constructor(private customerService: CustomerService) {}

  ngOnInit() {
    this.customerService.getFranchises().subscribe(data => {
      this.franchises = data;
    });
  }

  loadOutlets(franchiseId: number) {
    this.customerService.getOutlets(franchiseId).subscribe(data => {
      this.outlets = data;
    });
  }

  menu: MenuItem[] = [];
cart: MenuItem[] = [];

selectLocation(location: string) {
  this.selectedLocation = location;
  this.selectedOutletId = null;
  this.menu = [];
  this.cart = [];

  this.customerService.getOutletsByLocation(location)
    .subscribe(data => {
      this.outlets = data;
    });
}

loadMenu(outletId: number) {
  if (this.selectedOutletId && this.selectedOutletId !== outletId) {
    alert('You can only order from one outlet per order');
    return;
  }

  this.selectedOutletId = outletId;

  this.customerService.getMenu(outletId).subscribe(data => {
    this.menu = data;
  });
}


addToCart(item: MenuItem) {
  this.cart.push(item);
}

getTotal() {
  return this.cart.reduce((sum, i) => sum + i.price, 0);
}

placeOrder() {
  if (!this.selectedOutletId || this.cart.length === 0) {
    alert('Select outlet and add items to cart');
    return;
  }

  const order = {
    customerId: 4, // customer1
    outletId: this.selectedOutletId,
    totalAmount: this.getTotal(),
    items: this.cart.map(i => ({
      name: i.name,
      price: i.price,
      quantity: 1
    }))
  };

  this.customerService.placeOrder(order).subscribe(() => {
    alert('Order placed successfully');
    this.cart = [];
  });
}




}
