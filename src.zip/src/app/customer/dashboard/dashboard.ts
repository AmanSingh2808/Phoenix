import { Component, OnInit, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CustomerService } from '../../../app/services/customer.service';
import { Outlet } from '../../models/outlet';
import { MenuItem } from '../../models/menu-items';
import { Subject, Subscription } from 'rxjs';
import { switchMap, distinctUntilChanged } from 'rxjs/operators';

@Component({
  selector: 'app-customer-dashboard',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './dashboard.html',
  styleUrl: './dashboard.css'
})
export class CustomerDashboardComponent implements OnInit, OnDestroy {

  outlets: Outlet[] = [];
  locations: string[] = ['City Center', 'Mega Mall', 'North Zone'];
  selectedLocation = '';
  selectedOutletId: number | null = null;

  menu: MenuItem[] = [];
  cart: MenuItem[] = [];
  myOrders: any[] = [];

  private location$ = new Subject<string>();
  private locationSub!: Subscription;
  private orderPoller!: any;

  constructor(private customerService: CustomerService) {
    this.locationSub = this.location$
      .pipe(
        distinctUntilChanged(),
        switchMap(loc => this.customerService.getOutletsByLocation(loc))
      )
      .subscribe(data => {
        this.outlets = data;
      });
  }

  ngOnInit() {
    this.loadMyOrders();

    // Safe polling — does NOT touch outlet state
    this.orderPoller = setInterval(() => {
      this.loadMyOrders();
    }, 4000);
  }

  ngOnDestroy() {
    if (this.orderPoller) clearInterval(this.orderPoller);
    if (this.locationSub) this.locationSub.unsubscribe();
  }

  // ---------------------------
  // Location selection
  // ---------------------------
  selectLocation(location: string) {
    this.selectedLocation = location;
    this.selectedOutletId = null;
    this.menu = [];
    this.cart = [];
    this.location$.next(location);
  }

  onLocationChange(event: Event) {
    const value = (event.target as HTMLSelectElement).value;
    this.selectLocation(value);
  }

  // ---------------------------
  // Outlet → Menu
  // ---------------------------
  loadMenu(outletId: number) {
    if (this.selectedOutletId && this.selectedOutletId !== outletId) {
      alert('You can only order from one outlet per order');
      return;
    }

    this.selectedOutletId = outletId;

    this.customerService.getMenu(outletId).subscribe(data => {
      this.menu = data;
    });
  }

  trackOutlet(index: number, outlet: Outlet) {
    return outlet.id;
  }

  // ---------------------------
  // Cart
  // ---------------------------
  addToCart(item: MenuItem) {
    this.cart.push(item);
  }

  getTotal() {
    return this.cart.reduce((sum, i) => sum + i.price, 0);
  }

  // ---------------------------
  // Orders
  // ---------------------------
  placeOrder() {
    if (!this.selectedOutletId || this.cart.length === 0) {
      alert('Select outlet and add items to cart');
      return;
    }

    const user = JSON.parse(localStorage.getItem('user')!);

    const order = {
      customerId: user.id,
      outletId: this.selectedOutletId,
      totalAmount: this.getTotal(),
      items: this.cart.map(i => ({
        name: i.name,
        price: i.price,
        quantity: 1
      }))
    };

    this.customerService.placeOrder(order).subscribe(() => {
      alert('Order placed successfully');
      this.cart = [];
      this.loadMyOrders();
    });
  }

  loadMyOrders() {
    const user = JSON.parse(localStorage.getItem('user')!);

    this.customerService.getMyOrders(user.id)
      .subscribe(data => {
        this.myOrders = data as any[];
      });
  }
  
}
