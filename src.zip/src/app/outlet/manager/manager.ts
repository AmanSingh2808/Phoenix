import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { OutletService } from '../../services/outlet.service';

@Component({
  selector: 'app-outlet-manager',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './manager.html'
})
export class OutletManagerComponent implements OnInit {

  orders: any[] = [];
  outletId!: number;

  constructor(private outletService: OutletService) {}

  ngOnInit() {
    const user = JSON.parse(localStorage.getItem('user')!);

    this.outletService.getMyOutlet(user.id)
      .subscribe((outlet: any) => {
        this.outletId = outlet.id;
        this.loadOrders();
      });
  }

  loadOrders() {
  if (!this.outletId) return;

  this.outletService.getOrders(this.outletId)
    .subscribe((data: any[]) => {
      console.log('Orders:', data);

      // 🔥 Force Angular to re-render
      this.orders = [...data];
    });
}

}


