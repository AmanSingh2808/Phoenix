import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router, RouterModule } from '@angular/router';
import { AuthService } from '../auth';
@Component({
  selector: 'app-signup',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule],
  templateUrl: './signup.html', // <--- Matches your naming
  styleUrl: './signup.css'
})
export class SignupComponent {
  user = { name: '', email: '', password: '', role: 'CUSTOMER' };

  constructor(private authService: AuthService, private router: Router) {}

  onSignup() {
    this.authService.signup(this.user).subscribe({
      next: (res) => {
        alert('Signup Successful!');
        this.router.navigate(['/login']);
      },
      error: (err) => {
        alert('Signup Failed');
        console.error(err);
      }
    });
  }
}