import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { OutletService } from '../outlet';

@Component({
  selector: 'app-manager-dashboard',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './manager-dashboard.html',
  styleUrl: './manager-dashboard.css'
})
export class ManagerDashboardComponent implements OnInit {
  
  // --- STATE FLAGS ---
  hasOutlet: boolean = false; 
  isLoading: boolean = true;
  viewMode: 'ACTIVE' | 'HISTORY' = 'ACTIVE'; // Toggle for Order Tabs

  // --- DATA HOLDERS ---
  currentUser: any = null;
  existingOutlet: any = null;
  menuItems: any[] = [];
  
  // Order Arrays
  activeOrders: any[] = []; // Pending & Accepted
  pastOrders: any[] = [];   // Ready & Rejected
  
  // Constraint: Allowed Locations
  locations: string[] = ['VR Mall', 'Mega Mall', 'City Mall']; 

  // --- FORMS ---
  outletForm = { name: '', location: 'VR Mall', imageUrl: '', manager: null }; 
  menuForm = { name: '', description: '', price: 0, outlet: null };

  // --- CONSTRUCTOR ---
  constructor(private outletService: OutletService, private cdr: ChangeDetectorRef) {}

  // --- INITIALIZATION ---
  ngOnInit() {
    const userStr = localStorage.getItem('user');
    if (userStr) {
      this.currentUser = JSON.parse(userStr);
      this.checkStatus();
    } else {
      alert("Please Log In First");
      this.isLoading = false;
    }
  }

  // --- 1. CHECK STATUS ---
  checkStatus() {
    this.isLoading = true;
    
    this.outletService.getOutletByManager(this.currentUser.id).subscribe({
      next: (data) => {
        if (data && data.id) {
          this.hasOutlet = true;
          this.existingOutlet = data;
          this.loadMenu(); 
          this.loadOrders(); // Load orders immediately
        } else {
          this.hasOutlet = false;
        }
        this.isLoading = false;
        this.cdr.detectChanges(); 
      },
      error: (err) => {
        console.error("Error checking status:", err);
        this.isLoading = false;
      }
    });
  }

  // --- 2. CREATE OUTLET ---
  createOutlet() {
    const payload = {
      ...this.outletForm,
      manager: { id: this.currentUser.id }
    };

    this.outletService.addOutlet(payload).subscribe({
      next: () => {
        alert('Outlet Created! Waiting for Admin approval.');
        this.checkStatus(); 
      },
      error: () => alert('Failed to create outlet')
    });
  }

  // --- 3. MENU MANAGEMENT ---
  addMenuItem() {
    if (!this.existingOutlet || !this.existingOutlet.id) return;

    const payload = {
        name: this.menuForm.name,
        description: this.menuForm.description,
        price: this.menuForm.price,
        outlet: { id: this.existingOutlet.id } 
    };

    this.outletService.addMenuItem(payload).subscribe({
      next: () => {
        alert('Item Added Successfully!');
        this.menuForm = { name: '', description: '', price: 0, outlet: this.existingOutlet };
        this.loadMenu();
      },
      error: () => alert('Failed to add item')
    });
  }

  loadMenu() {
    if (!this.existingOutlet) return;
    this.outletService.getMenu(this.existingOutlet.id).subscribe({
      next: (data) => {
        this.menuItems = data;
        this.cdr.detectChanges();
      },
      error: (err) => console.error(err)
    });
  }

  // --- 4. ORDER MANAGEMENT (UPDATED) ---
  loadOrders() {
    if (!this.existingOutlet) return;
    
    this.outletService.getOutletOrders(this.existingOutlet.id).subscribe({
      next: (data) => {
        console.log("All Orders:", data);

        // FILTER: Split orders into Active and History
        this.activeOrders = data.filter((o: any) => o.status === 'PENDING' || o.status === 'ACCEPTED');
        this.pastOrders = data.filter((o: any) => o.status === 'READY' || o.status === 'REJECTED');

        // SORT: Newest first
        this.activeOrders.sort((a, b) => b.id - a.id);
        this.pastOrders.sort((a, b) => b.id - a.id);

        this.cdr.detectChanges();
      },
      error: (err) => console.error("Error fetching orders:", err)
    });
  }

  updateOrderStatus(orderId: number, status: string) {
    this.outletService.updateOrderStatus(orderId, status).subscribe({
      next: () => {
        this.loadOrders(); // Reload to move order to correct list
      },
      error: () => alert("Failed to update status")
    });
  }
}