import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet], // This enables the routing logic
  templateUrl: './app.html', // Pointing to your app.html
  styleUrl: './app.css'      // Pointing to your app.css
})
export class AppComponent {
  title = 'foodbox-frontend';
}