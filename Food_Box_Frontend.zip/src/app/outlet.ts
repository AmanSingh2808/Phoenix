import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class OutletService {
  private apiUrl = 'http://localhost:8080/api/outlets';
  private menuUrl = 'http://localhost:8080/api/menu'; // New URL

  constructor(private http: HttpClient) { }

  // --- EXISTING OUTLET METHODS ---
  getPublicOutlets(): Observable<any> {
    return this.http.get(`${this.apiUrl}/public`);
  }

  getAllOutlets(): Observable<any> {
    return this.http.get(`${this.apiUrl}/all`);
  }

  addOutlet(outlet: any): Observable<any> {
    return this.http.post(`${this.apiUrl}/add`, outlet);
  }

  updateOutlet(id: number, outlet: any): Observable<any> {
    return this.http.put(`${this.apiUrl}/${id}`, outlet);
  }

  deleteOutlet(id: number): Observable<any> {
    return this.http.delete(`${this.apiUrl}/${id}`);
  }

  // --- NEW MENU METHODS ---

  // 1. Get the outlet linked to a specific manager
  getOutletByManager(managerId: number): Observable<any> {
    return this.http.get(`${this.menuUrl}/my-outlet/${managerId}`);
  }

  // 2. Add a food item
  addMenuItem(item: any): Observable<any> {
    return this.http.post(`${this.menuUrl}/add`, item);
  }

  // 3. Get menu for an outlet
  getMenu(outletId: number): Observable<any> {
    return this.http.get(`${this.menuUrl}/${outletId}`);
  }

  placeOrder(orderRequest: any): Observable<any> {
    return this.http.post('http://localhost:8080/api/orders/place', orderRequest);
  }

  // 2. Get My Past Orders (For Customer)
  getCustomerOrders(customerId: number): Observable<any> {
    return this.http.get(`http://localhost:8080/api/orders/customer/${customerId}`);
  }
  
  // 3. Get Incoming Orders (For Manager)
  getOutletOrders(outletId: number): Observable<any> {
    return this.http.get(`http://localhost:8080/api/orders/outlet/${outletId}`);
  }

  // 4. Update Order Status
  updateOrderStatus(orderId: number, status: string): Observable<any> {
    return this.http.put(`http://localhost:8080/api/orders/update/${orderId}/${status}`, {});
  }
  
}