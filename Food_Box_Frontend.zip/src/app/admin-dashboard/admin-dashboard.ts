import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { OutletService } from '../outlet'; // Importing from outlet.ts

@Component({
  selector: 'app-admin-dashboard',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './admin-dashboard.html', // Corrected Name
  styleUrl: './admin-dashboard.css'      // Corrected Name
})
export class AdminDashboardComponent implements OnInit {
  
  outlets: any[] = [];

  constructor(private outletService: OutletService) {}

  ngOnInit() {
    this.loadOutlets();
  }

  loadOutlets() {
    this.outletService.getAllOutlets().subscribe({
      next: (data) => {
        console.log('Fetched Outlets:', data); // Check the browser console (F12)
        this.outlets = data;
      },
      error: (err) => console.error('Error fetching outlets:', err)
    });
  }

  toggleApproval(outlet: any) {
    outlet.approved = !outlet.approved; 
    if(outlet.approved) outlet.open = true; 

    this.outletService.updateOutlet(outlet.id, outlet).subscribe(() => {
      alert(`Outlet ${outlet.approved ? 'Approved' : 'Unapproved'}!`);
      this.loadOutlets(); 
    });
  }

  deleteOutlet(id: number) {
    if(confirm('Are you sure?')) {
      this.outletService.deleteOutlet(id).subscribe(() => {
        this.loadOutlets();
      });
    }
  }
}