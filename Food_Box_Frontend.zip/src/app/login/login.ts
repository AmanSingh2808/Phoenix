import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router, RouterModule } from '@angular/router';
import { AuthService } from '../auth';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule],
  templateUrl: './login.html', 
  styleUrl: './login.css'      
})
export class LoginComponent {
  credentials = { email: '', password: '' };

  constructor(private authService: AuthService, private router: Router) {}

  onLogin() {
    this.authService.login(this.credentials).subscribe({
      next: (user) => {
        alert('Login Successful! Role: ' + user.role);
        localStorage.setItem('user', JSON.stringify(user));

        if (user.role === 'ADMIN') {
          this.router.navigate(['/admin']);
        } 
        else if (user.role === 'MANAGER') {
          this.router.navigate(['/manager']);
        } 
        else if (user.role === 'CUSTOMER') {
          this.router.navigate(['/customer']);
        }
      },
      error: (err) => {
        alert('Login Failed');
        console.error(err);
      }
    });
  }
}