import { Routes } from '@angular/router';
import { LoginComponent } from './login/login';
import { SignupComponent } from './signup/signup';
import { ManagerDashboardComponent } from './manager-dashboard/manager-dashboard';
import { AdminDashboardComponent } from './admin-dashboard/admin-dashboard';
import { CustomerDashboardComponent } from './customer-dashboard/customer-dashboard'; // Import

export const routes: Routes = [
    { path: 'login', component: LoginComponent },
    { path: 'signup', component: SignupComponent },
    { path: 'manager', component: ManagerDashboardComponent },
    { path: 'admin', component: AdminDashboardComponent },
    { path: 'customer', component: CustomerDashboardComponent }, // New Route
    { path: '', redirectTo: 'login', pathMatch: 'full' }
];