import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { OutletService } from '../outlet';

@Component({
  selector: 'app-customer-dashboard',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './customer-dashboard.html',
  styleUrl: './customer-dashboard.css'
})
export class CustomerDashboardComponent implements OnInit {

  // --- DATA ---
  currentUser: any = null;
  allOutlets: any[] = [];
  filteredOutlets: any[] = [];
  menuItems: any[] = [];
  myOrders: any[] = []; // Stores order history

  // --- STATE ---
  selectedOutlet: any = null; // Shows Menu View if not null
  showHistory: boolean = false; // Shows History View if true

  // --- CART ---
  cart: any[] = [];
  cartTotal: number = 0;
  
  // --- FILTERS ---
  locations: string[] = ['All Locations', 'VR Mall', 'Mega Mall', 'City Mall'];
  selectedLocation: string = 'All Locations';

  constructor(private outletService: OutletService, private cdr: ChangeDetectorRef) {}

  ngOnInit() {
    // 1. Get User
    const userStr = localStorage.getItem('user');
    if (userStr) this.currentUser = JSON.parse(userStr);

    // 2. Load Data
    this.loadOutlets();
    if (this.currentUser) this.loadMyOrders();
  }

  // --- API CALLS ---

  loadOutlets() {
    this.outletService.getPublicOutlets().subscribe({
      next: (data) => {
        this.allOutlets = data;
        this.filteredOutlets = data;
        this.cdr.detectChanges();
      },
      error: (err) => console.error(err)
    });
  }

  loadMyOrders() {
    if (!this.currentUser) return;
    this.outletService.getCustomerOrders(this.currentUser.id).subscribe({
      next: (data) => {
        console.log("History Loaded:", data);
        this.myOrders = data;
        this.cdr.detectChanges();
      }
    });
  }

  // --- NAVIGATION & UI ---

  filterByLocation() {
    if (this.selectedLocation === 'All Locations') {
      this.filteredOutlets = this.allOutlets;
    } else {
      this.filteredOutlets = this.allOutlets.filter(o => o.location === this.selectedLocation);
    }
    this.selectedOutlet = null; 
  }

  toggleHistory() {
    this.showHistory = !this.showHistory;
    
    // If opening history, hide the menu
    if (this.showHistory) {
      this.selectedOutlet = null;
      this.loadMyOrders(); // Refresh status
    }
  }

  viewMenu(outlet: any) {
    this.selectedOutlet = outlet;
    this.showHistory = false; // Ensure history is hidden
    this.cart = []; // Clear cart (Rule: One shop at a time)
    this.cartTotal = 0;
    
    this.outletService.getMenu(outlet.id).subscribe({
      next: (data) => {
        this.menuItems = data;
        this.cdr.detectChanges(); 
      }
    });
  }

  backToList() {
    this.selectedOutlet = null;
    this.showHistory = false;
    this.menuItems = [];
    this.cart = [];
    this.cdr.detectChanges();
  }

  // --- CART LOGIC ---
  
  addToCart(item: any) {
    this.cart.push(item);
    this.cartTotal += item.price;
  }

  removeFromCart(index: number) {
    this.cartTotal -= this.cart[index].price;
    this.cart.splice(index, 1);
  }

  placeOrder() {
    if (this.cart.length === 0) return;
    if (!this.currentUser) {
        alert("Please Log In to order!");
        return;
    }

    const orderRequest = {
      customerId: this.currentUser.id,
      outletId: this.selectedOutlet.id,
      menuItemIds: this.cart.map(item => item.id)
    };

    this.outletService.placeOrder(orderRequest).subscribe({
      next: (res) => {
        alert(`Order Placed Successfully! Total: $${res.totalAmount}`);
        this.cart = [];
        this.cartTotal = 0;
        this.selectedOutlet = null; // Close menu
        this.showHistory = true;    // Show history automatically
        this.loadMyOrders();        // Refresh list
      },
      error: (err) => {
        console.error(err);
        alert("Failed to place order.");
      }
    });
  }
}