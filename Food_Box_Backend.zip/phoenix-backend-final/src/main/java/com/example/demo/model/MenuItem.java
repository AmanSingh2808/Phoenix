package com.example.demo.model;

import jakarta.persistence.*;
import com.fasterxml.jackson.annotation.JsonIgnore; // Import this to prevent infinite loops

@Entity
@Table(name = "menu_items")
public class MenuItem {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;
    private String description;
    private Double price;

    // Link to the Outlet this item belongs to
    @ManyToOne
    @JoinColumn(name = "outlet_id")
    private Outlet outlet;

    // --- CONSTRUCTORS ---
    public MenuItem() {}

    public MenuItem(String name, String description, Double price, Outlet outlet) {
        this.name = name;
        this.description = description;
        this.price = price;
        this.outlet = outlet;
    }

    // --- GETTERS AND SETTERS ---
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public Double getPrice() { return price; }
    public void setPrice(Double price) { this.price = price; }

    public Outlet getOutlet() { return outlet; }
    public void setOutlet(Outlet outlet) { this.outlet = outlet; }
}