package com.example.demo.controller;

import com.example.demo.model.*;
import com.example.demo.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.bind.annotation.RequestMethod;
import java.util.List;

@RestController
@RequestMapping("/api/orders")
@CrossOrigin(origins = "http://localhost:4200", methods = {RequestMethod.GET, RequestMethod.POST, RequestMethod.PUT, RequestMethod.DELETE})
public class OrderController {

    @Autowired
    private OrderRepository orderRepository;
    @Autowired
    private UserRepository userRepository;
    @Autowired
    private OutletRepository outletRepository;
    @Autowired
    private MenuItemRepository menuItemRepository;

    // 1. PLACE ORDER
    @PostMapping("/place")
    public Order placeOrder(@RequestBody OrderRequest request) {
        Order order = new Order();
        
        // Fetch Customer & Outlet from DB
        User customer = userRepository.findById(request.getCustomerId()).orElse(null);
        Outlet outlet = outletRepository.findById(request.getOutletId()).orElse(null);
        
        // Fetch All Menu Items by their IDs
        List<MenuItem> items = menuItemRepository.findAllById(request.getMenuItemIds());

        // Calculate Total Price
        double total = 0;
        for (MenuItem item : items) {
            total += item.getPrice();
        }

        order.setCustomer(customer);
        order.setOutlet(outlet);
        order.setItems(items);
        order.setTotalAmount(total);

        return orderRepository.save(order);
    }

    // 2. GET CUSTOMER ORDERS
    @GetMapping("/customer/{customerId}")
    public List<Order> getCustomerOrders(@PathVariable Long customerId) {
        return orderRepository.findByCustomerId(customerId);
    }

    // 3. GET MANAGER ORDERS
    @GetMapping("/outlet/{outletId}")
    public List<Order> getOutletOrders(@PathVariable Long outletId) {
        return orderRepository.findByOutletId(outletId);
    }
    
 // 4. UPDATE ORDER STATUS
    @PutMapping("/update/{orderId}/{status}")
    public Order updateStatus(@PathVariable Long orderId, @PathVariable String status) {
        Order order = orderRepository.findById(orderId).orElse(null);
        if (order != null) {
            order.setStatus(status.toUpperCase());
            return orderRepository.save(order);
        }
        return null;
    }
}