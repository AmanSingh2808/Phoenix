package com.example.demo.controller;

import com.example.demo.model.MenuItem;
import com.example.demo.model.Outlet;
import com.example.demo.service.MenuService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/menu")
@CrossOrigin(origins = "http://localhost:4200")
public class MenuController {

    @Autowired
    private MenuService menuService;

    // Get menu for a specific outlet
    @GetMapping("/{outletId}")
    public List<MenuItem> getMenu(@PathVariable Long outletId) {
        // Ensure we are passing the ID from the URL to the Service
        return menuService.getMenuByOutlet(outletId);
    }
    // Add item to menu
    @PostMapping("/add")
    public MenuItem addMenuItem(@RequestBody MenuItem item) {
        return menuService.addMenuItem(item);
    }

    // Helper: Get My Outlet (For Manager Dashboard)
    @GetMapping("/my-outlet/{managerId}")
    public Outlet getMyOutlet(@PathVariable Long managerId) {
        return menuService.getOutletByManager(managerId);
    }
}