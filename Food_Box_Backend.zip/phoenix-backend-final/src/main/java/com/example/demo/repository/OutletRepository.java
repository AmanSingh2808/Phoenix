package com.example.demo.repository;

import com.example.demo.model.Outlet;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface OutletRepository extends JpaRepository<Outlet, Long> {
    
    // For Customers: Show only shops that are Approved AND Open
    List<Outlet> findByIsApprovedTrueAndIsOpenTrue();
    
    // For Admin: Show all shops (to approve them)
    // (findAll() is already provided by JpaRepository)
    
    // For Manager: Find their specific outlet
    Outlet findByManagerId(Long managerId);
}