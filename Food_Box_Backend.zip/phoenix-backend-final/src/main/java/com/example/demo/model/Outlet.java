package com.example.demo.model;

import jakarta.persistence.*;

@Entity
@Table(name = "outlets")
public class Outlet {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;
    private String location;
    private String imageUrl;
    
    private boolean isOpen;     
    private boolean isApproved; 

    @OneToOne // <--- This indicates One-to-One relationship
    @JoinColumn(name = "manager_id", unique = true) // <--- ADD "unique = true"
    private User manager; 

    // ... (Keep your Constructors, Getters, and Setters the same) ...
    public Outlet() {}
    
    // Copy the rest of the file content you already had...
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getLocation() { return location; }
    public void setLocation(String location) { this.location = location; }
    public String getImageUrl() { return imageUrl; }
    public void setImageUrl(String imageUrl) { this.imageUrl = imageUrl; }
    public boolean isOpen() { return isOpen; }
    public void setOpen(boolean open) { isOpen = open; }
    public boolean isApproved() { return isApproved; }
    public void setApproved(boolean approved) { isApproved = approved; }
    public User getManager() { return manager; }
    public void setManager(User manager) { this.manager = manager; }
}