package com.example.demo.controller;

import com.example.demo.model.Outlet;
import com.example.demo.service.OutletService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/outlets")
@CrossOrigin(origins = "http://localhost:4200")
public class OutletController {

    @Autowired
    private OutletService outletService;

    // Public: Get List of Open Shops (For Customers)
    @GetMapping("/public")
    public List<Outlet> getPublicOutlets() {
        return outletService.getPublicOutlets();
    }

    // Admin: Get ALL Shops
    @GetMapping("/all")
    public List<Outlet> getAllOutlets() {
        return outletService.getAllOutlets();
    }

    // Manager: Add a new Shop
    @PostMapping("/add")
    public Outlet addOutlet(@RequestBody Outlet outlet) {
        return outletService.addOutlet(outlet);
    }

    // Manager/Admin: Update Shop (Open/Close or Approve)
    @PutMapping("/{id}")
    public Outlet updateOutlet(@PathVariable Long id, @RequestBody Outlet outlet) {
        return outletService.updateOutlet(id, outlet);
    }
    
    // Admin: Delete Shop
    @DeleteMapping("/{id}")
    public void deleteOutlet(@PathVariable Long id) {
        outletService.deleteOutlet(id);
    }
}