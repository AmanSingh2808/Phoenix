package com.example.demo.model;

import java.util.List;

public class OrderRequest {
    private Long customerId;
    private Long outletId;
    private List<Long> menuItemIds; // Just the IDs of the food

    // Getters and Setters
    public Long getCustomerId() { return customerId; }
    public void setCustomerId(Long customerId) { this.customerId = customerId; }

    public Long getOutletId() { return outletId; }
    public void setOutletId(Long outletId) { this.outletId = outletId; }

    public List<Long> getMenuItemIds() { return menuItemIds; }
    public void setMenuItemIds(List<Long> menuItemIds) { this.menuItemIds = menuItemIds; }
}