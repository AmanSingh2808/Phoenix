package com.example.demo.controller;

import com.example.demo.model.User;
import com.example.demo.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/auth")
@CrossOrigin(origins = "http://localhost:4200") // This allows Angular to communicate
public class AuthController {

    @Autowired
    private UserService userService;

    @PostMapping("/signup")
    public User signup(@RequestBody User user) {
        return userService.registerUser(user);
    }

    @PostMapping("/login")
    public User login(@RequestBody User loginDetails) {
        User user = userService.loginUser(loginDetails.getEmail(), loginDetails.getPassword());
        if (user != null) {
            return user;
        } else {
            throw new RuntimeException("Invalid Credentials");
        }
    }
}