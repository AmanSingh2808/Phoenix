package com.example.demo.repository;

import com.example.demo.model.MenuItem;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface MenuItemRepository extends JpaRepository<MenuItem, Long> {
    
    // CRITICAL: This method filters the database. 
    // It looks for items where 'outlet.id' matches the variable passed in.
    List<MenuItem> findByOutletId(Long outletId); 
}