package com.example.demo.repository;

import com.example.demo.model.Order;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface OrderRepository extends JpaRepository<Order, Long> {
    // For Customer: See my past orders
    List<Order> findByCustomerId(Long customerId);
    
    // For Manager: See orders for my shop
    List<Order> findByOutletId(Long outletId);
}