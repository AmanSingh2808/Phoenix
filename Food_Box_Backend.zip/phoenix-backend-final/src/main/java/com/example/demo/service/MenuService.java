package com.example.demo.service;

import com.example.demo.model.MenuItem;
import com.example.demo.model.Outlet;
import com.example.demo.repository.MenuItemRepository;
import com.example.demo.repository.OutletRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class MenuService {

    @Autowired
    private MenuItemRepository menuItemRepository;
    
    @Autowired
    private OutletRepository outletRepository;

    public MenuItem addMenuItem(MenuItem item) {
        // SAFETY CHECK: Ensure the item is linked to a valid Outlet
        if (item.getOutlet() != null && item.getOutlet().getId() != null) {
            Outlet realOutlet = outletRepository.findById(item.getOutlet().getId()).orElse(null);
            item.setOutlet(realOutlet); // Link the "Real" database object
        }
        return menuItemRepository.save(item);
    }

    public List<MenuItem> getMenuByOutlet(Long outletId) {
        return menuItemRepository.findByOutletId(outletId); // <--- Only gets specific items
    }
    
    // Helper to find outlet by manager ID (so manager doesn't need to guess their outlet ID)
    public Outlet getOutletByManager(Long managerId) {
        return outletRepository.findByManagerId(managerId);
    }
}