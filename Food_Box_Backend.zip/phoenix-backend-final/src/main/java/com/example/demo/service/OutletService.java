package com.example.demo.service;

import com.example.demo.model.Outlet;
import com.example.demo.model.User;
import com.example.demo.repository.OutletRepository;
import com.example.demo.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class OutletService {

    @Autowired
    private OutletRepository outletRepository;

    @Autowired
    private UserRepository userRepository;

    public Outlet addOutlet(Outlet outlet) {
        // 1. Validate Manager
        if (outlet.getManager() != null && outlet.getManager().getId() != null) {
            
            Long managerId = outlet.getManager().getId();
            
            // --- NEW CONSTRAINT CHECK ---
            // Check if this manager already has an outlet in the DB
            Outlet existingOutlet = outletRepository.findByManagerId(managerId);
            if (existingOutlet != null) {
                throw new RuntimeException("This Manager already owns an outlet!");
            }
            // -----------------------------

            User realManager = userRepository.findById(managerId).orElse(null);
            outlet.setManager(realManager);
        }
        
        return outletRepository.save(outlet);
    }

    // ... (Keep the rest of your methods: getAllOutlets, getPublicOutlets, etc. unchanged) ...
    public List<Outlet> getAllOutlets() { return outletRepository.findAll(); }
    public List<Outlet> getPublicOutlets() { return outletRepository.findByIsApprovedTrueAndIsOpenTrue(); }
    
    public Outlet updateOutlet(Long id, Outlet updatedOutlet) {
        Outlet existing = outletRepository.findById(id).orElse(null);
        if(existing != null) {
            existing.setName(updatedOutlet.getName());
            existing.setLocation(updatedOutlet.getLocation());
            existing.setImageUrl(updatedOutlet.getImageUrl());
            existing.setOpen(updatedOutlet.isOpen());
            existing.setApproved(updatedOutlet.isApproved());
            return outletRepository.save(existing);
        }
        return null;
    }
    
    public void deleteOutlet(Long id) { outletRepository.deleteById(id); }
}