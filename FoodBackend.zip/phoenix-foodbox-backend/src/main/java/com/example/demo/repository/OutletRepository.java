package com.example.demo.repository;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import com.example.demo.model.Outlet;

public interface OutletRepository extends JpaRepository<Outlet, Long> {
    List<Outlet> findByFranchiseId(Long franchiseId);
    List<Outlet> findByLocation(String location);
}
