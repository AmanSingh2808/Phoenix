package com.example.demo.model;

public enum OrderStatus {
    PLACED,
    ACCEPTED,
    PREPARING,
    READY,
    COMPLETED
}
