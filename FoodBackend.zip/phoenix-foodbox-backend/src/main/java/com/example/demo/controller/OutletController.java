package com.example.demo.controller;

import java.util.List;
import org.springframework.web.bind.annotation.*;

import com.example.demo.model.Outlet;
import com.example.demo.repository.OutletRepository;

@RestController
@RequestMapping("/api/outlets")
@CrossOrigin(origins = "http://localhost:4200")
public class OutletController {

    private final OutletRepository outletRepo;

    public OutletController(OutletRepository outletRepo) {
        this.outletRepo = outletRepo;
    }

    @GetMapping
    public List<Outlet> getOutletsByLocation(@RequestParam String location) {
        return outletRepo.findByLocation(location);
    }
}
