package com.example.demo.controller;

import java.util.List;
import org.springframework.web.bind.annotation.*;

import com.example.demo.model.*;
import com.example.demo.repository.*;

@RestController
@RequestMapping("/api/orders")
@CrossOrigin(origins = "http://localhost:4200")
public class OrderController {

    private final OrderRepository orderRepo;
    private final UserRepository userRepo;
    private final OutletRepository outletRepo;

    public OrderController(OrderRepository orderRepo,
                           UserRepository userRepo,
                           OutletRepository outletRepo) {
        this.orderRepo = orderRepo;
        this.userRepo = userRepo;
        this.outletRepo = outletRepo;
    }

    @PostMapping("/place")
    public Order placeOrder(@RequestBody OrderRequest request) {

        User customer = userRepo.findById(request.customerId()).orElseThrow();
        Outlet outlet = outletRepo.findById(request.outletId()).orElseThrow();

        Order newOrder = new Order(
                customer,
                outlet,
                request.totalAmount()
        );

        Order savedOrder = orderRepo.save(newOrder); // ✅ final reference

        List<OrderItem> items = request.items().stream()
                .map(i -> new OrderItem(
                        i.name(),
                        i.price(),
                        i.quantity(),
                        savedOrder
                ))
                .toList();

        savedOrder.setItems(items);
        return orderRepo.save(savedOrder);
    }


    @GetMapping("/customer/{id}")
    public List<Order> getCustomerOrders(@PathVariable Long id) {
        return orderRepo.findByCustomerId(id);
    }
}
