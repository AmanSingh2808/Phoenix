package com.example.demo;

import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;

import com.example.demo.model.*;
import com.example.demo.repository.UserRepository;

@Component
@Configuration
public class DataLoader {

    @Bean
    CommandLineRunner run(UserRepository repo){
        return args -> {

            if(repo.count() == 0){

                repo.save(new User("admin","admin123",Role.ADMIN));
                repo.save(new User("owner1","pass123",Role.FRANCHISE_OWNER));
                repo.save(new User("manager1","pass123",Role.OUTLET_MANAGER));
                repo.save(new User("customer1","pass123",Role.CUSTOMER));
            }
        };
    }
}
