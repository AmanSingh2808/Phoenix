package com.example.demo.service;

import org.springframework.stereotype.Service;

import com.example.demo.model.*;
import com.example.demo.repository.UserRepository;

@Service
public class AuthService {

    private final UserRepository repo;

    public AuthService(UserRepository repo){
        this.repo = repo;
    }

    public User register(User user){
        return repo.save(user);
    }

    public User login(String username,String password){
        return repo.findByUsername(username)
                .filter(u -> u.getPassword().equals(password))
                .orElse(null);
    }
}

