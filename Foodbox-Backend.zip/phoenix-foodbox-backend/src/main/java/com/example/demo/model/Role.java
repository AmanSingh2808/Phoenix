package com.example.demo.model;

public enum Role {
	ADMIN,
    FRANCHISE_OWNER,
    OUTLET_MANAGER,
    CUSTOMER
}
