import { Component, OnInit } from '@angular/core';
import { OutletService } from '../../services/outlet.service';
import { CommonModule } from '@angular/common';
import { interval } from 'rxjs';


@Component({
  selector: 'app-outlet-manager',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './manager.html',
  styleUrl: './manager.css'
})
export class OutletManagerComponent implements OnInit {

  outletId!: number;
  orders: any[] = [];

  constructor(private outletService: OutletService) {}

 ngOnInit() {
  const user = JSON.parse(localStorage.getItem('user')!);

  this.outletService.getMyOutlet(user.id).subscribe(outlet => {
  console.log("Manager outlet:", outlet);
  this.outletId = outlet.id;
  this.loadOrders();
});
  interval(5000).subscribe(() => this.loadOrders());
}


  loadOrders() {
    this.outletService.getOrders(this.outletId)
      .subscribe(data => this.orders = data);
  }

  accept(id: number) {
  this.outletService.accept(id).subscribe(() => {
    this.loadOrders();
  });
}

start(id: number) {
  this.outletService.start(id).subscribe(() => {
    this.loadOrders();
  });
}

ready(id: number) {
  this.outletService.ready(id).subscribe(() => {
    this.loadOrders();
  });
}

complete(id: number) {
  this.outletService.complete(id).subscribe(() => {
    this.loadOrders();
  });
}



}
