import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CustomerService } from '../../../app/services/customer.service';
import { Outlet } from '../../models/outlet';
import { MenuItem } from '../../models/menu-items';
import { Subject } from 'rxjs';
import { switchMap } from 'rxjs/operators';


@Component({
  selector: 'app-customer-dashboard',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './dashboard.html',
  styleUrl: './dashboard.css'
})
export class CustomerDashboardComponent {

  
  outlets: Outlet[] = [];
  locations: string[] = ['City Center', 'Mega Mall', 'North Zone'];
  selectedLocation = '';
  selectedOutletId: number | null = null;
  private location$ = new Subject<string>();



 constructor(private customerService: CustomerService) {
  this.location$
    .pipe(
      switchMap(loc => this.customerService.getOutletsByLocation(loc))
    )
    .subscribe(data => {
      this.outlets = data;
    });
}



menu: MenuItem[] = [];
cart: MenuItem[] = [];

selectLocation(location: string) {
  this.selectedLocation = location;
  this.selectedOutletId = null;
  this.menu = [];
  this.cart = [];

  this.location$.next(location);
}



loadMenu(outletId: number) {
  if (this.selectedOutletId && this.selectedOutletId !== outletId) {
    alert('You can only order from one location per order');
    return;
  }

  this.selectedOutletId = outletId;

  this.customerService.getMenu(outletId).subscribe(data => {
    this.menu = data;
  });
}


addToCart(item: MenuItem) {
  this.cart.push(item);
}

getTotal() {
  return this.cart.reduce((sum, i) => sum + i.price, 0);
}

placeOrder() {
  if (!this.selectedOutletId || this.cart.length === 0) {
    alert('Select outlet and add items to cart');
    return;
  }

  const order = {
    customerId: 4, // customer1
    outletId: this.selectedOutletId,
    totalAmount: this.getTotal(),
    items: this.cart.map(i => ({
      name: i.name,
      price: i.price,
      quantity: 1
    }))
  };

  this.customerService.placeOrder(order).subscribe(() => {
    alert('Order placed successfully');
    this.cart = [];
  });
}

onLocationChange(event: Event) {
  const value = (event.target as HTMLSelectElement).value;
  this.selectLocation(value);
}

trackOutlet(index: number, outlet: Outlet) {
  return outlet.id;
}





}
